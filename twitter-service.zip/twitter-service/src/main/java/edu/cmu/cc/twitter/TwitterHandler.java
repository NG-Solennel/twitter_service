package edu.cmu.cc.twitter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariDataSource;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;

import java.sql.*;
import java.util.*;

public class TwitterHandler implements HttpHandler {

    private static final String ANDREW_ID = System.getenv("ANDREW_ID") != null
        ? System.getenv("ANDREW_ID") : "sgisubiz";
    private static final String AWS_ACCOUNT_ID = "225220763449";

    private static final Set<String> VALID_TYPES = new HashSet<>(
        Arrays.asList("reply", "retweet", "both"));

    private final HikariDataSource ds;
    private final String authUrl;
    private final ObjectMapper mapper = new ObjectMapper();
    private final CloseableHttpClient httpClient;

    public TwitterHandler(HikariDataSource ds, String authUrl) {
        this.ds = ds;
        this.authUrl = authUrl;
        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(200);
        cm.setDefaultMaxPerRoute(200);
        this.httpClient = HttpClients.custom().setConnectionManager(cm).build();
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) throws Exception {
        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "text/plain");

        Map<String, Deque<String>> params = exchange.getQueryParameters();

        String userIdStr = getParam(params, "user_id");
        String type      = getParam(params, "type");
        String phrase    = getParam(params, "phrase");
        String hashtag   = getParam(params, "hashtag");
        String timestamp = getParam(params, "timestamp");

        // Validate all required params present
        if (userIdStr == null || type == null || phrase == null
            || hashtag == null || timestamp == null) {
            sendInvalid(exchange);
            return;
        }

        // Validate type
        if (!VALID_TYPES.contains(type)) {
            sendInvalid(exchange);
            return;
        }

        long userId;
        long ts;
        try {
            userId = Long.parseLong(userIdStr);
            ts     = Long.parseLong(timestamp);
        } catch (NumberFormatException e) {
            sendInvalid(exchange);
            return;
        }

        // URL decode phrase
        String decodedPhrase;
        try {
            decodedPhrase = java.net.URLDecoder.decode(phrase, "UTF-8");
        } catch (Exception e) {
            decodedPhrase = phrase;
        }

        // Get auth token
        String token = getToken(ts);

        // Check if user has ANY contacts at all (both reply+retweet)
        if (!userHasAnyContacts(userId)) {
            // User has no contact tweets at all - return INVALID
            sendInvalid(exchange);
            return;
        }

        // Get results
        List<ResultRow> results = getResults(userId, type, decodedPhrase, hashtag);

        // Build response
        StringBuilder sb = new StringBuilder();
        sb.append(ANDREW_ID).append(",").append(AWS_ACCOUNT_ID)
          .append(",").append(token).append("\n");

        for (int i = 0; i < results.size(); i++) {
            ResultRow row = results.get(i);
            sb.append(row.userId).append("\t")
              .append(row.screenName != null ? row.screenName : "").append("\t")
              .append(row.description != null ? row.description : "").append("\t")
              .append(row.tweetText != null ? row.tweetText : "");
            if (i < results.size() - 1) {
                sb.append("\n");
            }
        }

        exchange.getResponseSender().send(sb.toString());
    }

    private boolean userHasAnyContacts(long userId) {
        String sql = "SELECT 1 FROM contacts WHERE user_id = ? LIMIT 1";
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            return false;
        }
    }

    private List<ResultRow> getResults(long userId, String type,
                                        String phrase, String hashtag) throws SQLException {
        List<ContactInfo> contacts = getContacts(userId);
        if (contacts.isEmpty()) return Collections.emptyList();

        List<ResultRow> results = new ArrayList<>();

        for (ContactInfo contact : contacts) {
            // Interaction score: log(1 + 2*reply + retweet)
            double interactionScore = Math.log(1.0
                + 2.0 * contact.replyCount
                + 1.0 * contact.retweetCount);

            // Hashtag score
            double hashtagScore = getHashtagScore(userId, contact.contactedUserId);

            // Keywords score
            double keywordsScore = getKeywordsScore(
                userId, contact.contactedUserId, type, phrase, hashtag);

            double finalScore = interactionScore * hashtagScore * keywordsScore;

            if (finalScore <= 0) continue;

            // Round to 5 decimal places half-up
            finalScore = Math.round(finalScore * 100000.0) / 100000.0;

            // Get user info
            UserInfo userInfo = getUserInfo(contact.contactedUserId);
            if (userInfo == null) {
                userInfo = new UserInfo("", "");
            }

            // Get latest contact tweet of requested type
            String tweetText = getLatestContactTweet(
                userId, contact.contactedUserId, type);
            if (tweetText == null) continue;

            results.add(new ResultRow(
                contact.contactedUserId,
                userInfo.screenName,
                userInfo.description,
                tweetText,
                finalScore));
        }

        // Sort: score desc, then user_id desc
        results.sort((a, b) -> {
            int cmp = Double.compare(b.score, a.score);
            if (cmp != 0) return cmp;
            return Long.compare(b.userId, a.userId);
        });

        return results;
    }

    private List<ContactInfo> getContacts(long userId) throws SQLException {
        String sql = "SELECT contacted_user_id, reply_count, retweet_count "
                   + "FROM contacts WHERE user_id = ?";
        List<ContactInfo> list = new ArrayList<>();
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new ContactInfo(rs.getLong(1), rs.getInt(2), rs.getInt(3)));
                }
            }
        }
        return list;
    }

    private double getHashtagScore(long userId, long contactedUserId) throws SQLException {
        // Self-contact always returns 1
        if (userId == contactedUserId) return 1.0;

        String sql = "SELECT SUM(a.count * b.count) "
                   + "FROM user_hashtags a "
                   + "JOIN user_hashtags b ON a.hashtag = b.hashtag "
                   + "WHERE a.user_id = ? AND b.user_id = ?";
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, contactedUserId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    long sameTagCount = rs.getLong(1);
                    if (sameTagCount > 10) {
                        return 1.0 + Math.log(1.0 + sameTagCount - 10.0);
                    }
                }
            }
        }
        return 1.0;
    }

    private double getKeywordsScore(long userId, long contactedUserId,
                                     String type, String phrase, String hashtag)
            throws SQLException {
        String sql;
        if ("both".equals(type)) {
            sql = "SELECT tweet_text FROM contact_tweets "
                + "WHERE user_id = ? AND contacted_user_id = ?";
        } else {
            sql = "SELECT tweet_text FROM contact_tweets "
                + "WHERE user_id = ? AND contacted_user_id = ? AND tweet_type = ?";
        }

        List<String> texts = new ArrayList<>();
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, contactedUserId);
            if (!"both".equals(type)) ps.setString(3, type);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String t = rs.getString(1);
                    if (t != null) texts.add(t);
                }
            }
        }

        if (texts.isEmpty()) return 0.0;

        int totalMatches = 0;
        String lowerHashtag = hashtag.toLowerCase(Locale.ENGLISH);

        for (String text : texts) {
            // Phrase: case-sensitive substring count
            if (!phrase.isEmpty()) {
                totalMatches += countOccurrences(text, phrase);
            }
            // Hashtag: case-insensitive exact match on #hashtag
            totalMatches += countHashtagMatches(text, lowerHashtag);
        }

        return 1.0 + Math.log(totalMatches + 1);
    }

    private int countOccurrences(String text, String pattern) {
        if (pattern.isEmpty()) return 0;
        int count = 0, idx = 0;
        while ((idx = text.indexOf(pattern, idx)) != -1) {
            count++;
            idx++;
        }
        return count;
    }

    private int countHashtagMatches(String text, String hashtag) {
        int count = 0;
        String lowerText = text.toLowerCase(Locale.ENGLISH);
        String pattern = "#" + hashtag;
        int idx = 0;
        while ((idx = lowerText.indexOf(pattern, idx)) != -1) {
            int end = idx + pattern.length();
            if (end >= lowerText.length()
                || !Character.isLetterOrDigit(lowerText.charAt(end))) {
                count++;
            }
            idx++;
        }
        return count;
    }

    private UserInfo getUserInfo(long userId) throws SQLException {
        String sql = "SELECT screen_name, description FROM users WHERE user_id = ?";
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new UserInfo(rs.getString(1), rs.getString(2));
            }
        }
        return null;
    }

    private String getLatestContactTweet(long userId, long contactedUserId,
                                          String type) throws SQLException {
        String sql;
        if ("both".equals(type)) {
            // Return whichever type exists, prefer retweet over reply if both exist
            sql = "SELECT tweet_text FROM contact_tweets "
                + "WHERE user_id = ? AND contacted_user_id = ? LIMIT 1";
        } else {
            sql = "SELECT tweet_text FROM contact_tweets "
                + "WHERE user_id = ? AND contacted_user_id = ? AND tweet_type = ?";
        }
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, contactedUserId);
            if (!"both".equals(type)) ps.setString(3, type);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString(1);
            }
        }
        return null;
    }

    private String getToken(long timestamp) {
        try {
            Map<String, Object> body = new HashMap<>();
            body.put("andrew_id", ANDREW_ID);
            body.put("timestamp", timestamp);

            HttpPost post = new HttpPost(authUrl + "/rest_auth");
            post.setEntity(new StringEntity(
                mapper.writeValueAsString(body),
                ContentType.APPLICATION_JSON));

            try (CloseableHttpResponse resp = httpClient.execute(post)) {
                String json = new String(resp.getEntity().getContent().readAllBytes());
                Map<?, ?> result = mapper.readValue(json, Map.class);
                Object token = result.get("token");
                return token != null ? token.toString() : "error";
            }
        } catch (Exception e) {
            return "error";
        }
    }

    private void sendInvalid(HttpServerExchange exchange) {
        exchange.getResponseSender().send(
            ANDREW_ID + "," + AWS_ACCOUNT_ID + "\nINVALID");
    }

    private String getParam(Map<String, Deque<String>> params, String key) {
        Deque<String> vals = params.get(key);
        if (vals == null || vals.isEmpty()) return null;
        String val = vals.peek();
        return (val == null || val.isEmpty()) ? null : val;
    }

    // ── Inner classes ──────────────────────────────────────────────────────

    static class ContactInfo {
        long contactedUserId;
        int replyCount, retweetCount;
        ContactInfo(long c, int r, int rt) {
            contactedUserId = c; replyCount = r; retweetCount = rt;
        }
    }

    static class UserInfo {
        String screenName, description;
        UserInfo(String s, String d) {
            screenName  = s != null ? s : "";
            description = d != null ? d : "";
        }
    }

    static class ResultRow {
        long userId;
        String screenName, description, tweetText;
        double score;
        ResultRow(long u, String s, String d, String t, double sc) {
            userId = u; screenName = s; description = d; tweetText = t; score = sc;
        }
    }
}
